public class Person {
    String name;
    int age;
    boolean isAlive;
    boolean isWorking;

    void przedstawSie() {
        System.out.println("Elo jestem " + name + " mam " + age + " lat.");

    }
}
