public class Test1 {
    public static void main(String[] args) {
        int i = 1, sum = 0;
        while(i <= 30) {
            sum += i;
            i++;
        }
        System.out.println("Sum = " + sum);
    }
}