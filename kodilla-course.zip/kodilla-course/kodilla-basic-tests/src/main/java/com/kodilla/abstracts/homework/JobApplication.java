package com.kodilla.abstracts.homework;

public class JobApplication {
}
