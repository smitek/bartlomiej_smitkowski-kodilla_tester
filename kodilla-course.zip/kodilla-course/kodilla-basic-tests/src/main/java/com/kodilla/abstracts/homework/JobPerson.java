package com.kodilla.abstracts.homework;

public class JobPerson extends Job{
    public JobPerson(String Tomek, int 35, String JobDriver) {

    }
}
