package com.kodilla.abstracts.homework;

public abstract class Shape {
    abstract double pole();
    abstract double obwod();
}
