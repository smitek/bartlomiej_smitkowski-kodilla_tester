package com.kodilla.abstracts.homework;

public abstract class Job {
    abstract double salary();
    abstract double responsibilities();
}
