package com.kodilla.abstracts.homework;

public class Kwadrat extends Shape{
    public double a;

    public double pole(){
        return a*a;
    }
    public double obwod(){
        return 4*a;
    }
}
