package com.kodilla.inheritance.homework;

public class OperatingSystem_0 {

    public static void main(String[] args){
        OperatingSystem operatingSystem = new OperatingSystem (1995, 2015);
        operatingSystem.turnOn();
        operatingSystem.turnOff();
    }
}
